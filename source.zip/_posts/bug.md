---
title: bug汇总
date: 2021-08-02 17:17:05
tags: bug
---
# bug汇总
## 记一次使用fastjson对象拷贝的bug
执行下面这行代码
```
ModelVo modelVo = JSONObject.parseObject(JSONObject.toJSONString(model), ModelVo.class);
```
报错
`fastjson  java.lang.IllegalArgumentException: argument type mismatch`

*原因就是内部类的层次不够。以下面的例子举例*
```

public class ModelVo {
    public Data data;
    public class Data {
        public List<Row> rows;
    }
    public class Row{
    }
}
```
应该改成这样
```
public class ModelVo {
    public Data data;
    public class Data {
        public List<Row> rows;
         public class Row{
        }
    }
}
```
## 按日期分组（group by）查询统计的时候，没有数据补0

网上关于这个问题的解决方案大致是生成一个日历表，往里面插足够多的日期数据然后和原来的数据，联合查询。我觉得这个方案不是很好，但是也给我提供了一些思路。我需要一张日期表，但我又不想建表。可以union all日期生成一张临时表然后左外连接你需要的数据。

比如说你想查一个最近7天的数据

```
select a.click_date, ifnull(b.count1, 0) as count1
from (
         SELECT curdate() as click_date
         union all
         SELECT date_sub(curdate(), interval 1 day) as click_date
         union all
         SELECT date_sub(curdate(), interval 2 day) as click_date
         union all
         SELECT date_sub(curdate(), interval 3 day) as click_date
         union all
         SELECT date_sub(curdate(), interval 4 day) as click_date
         union all
         SELECT date_sub(curdate(), interval 5 day) as click_date
         union all
         SELECT date_sub(curdate(), interval 6 day) as click_date) a
         left join (select date(alarmtime) as datetime, count(*) as count1
                    from error
                    where type = 1
                    group by date(alarmtime)) b on a.click_date = b.datetime
```               

但是如果业务复杂一些，比如说我想知道*开始时间-结束时间*的数据，这就不像7天，30天这样可以直接写在sql里了，而且如果我想知道一年，你应该也不会一直在后面追加一年的日期
不过思路是对的，只不过这张日期表我们可以通过代码去拼接sql，这样不管再长的间隔也不需要我们手动拼接了。

```
//拿到指定开始时间-结束时间所有的日期
List<String> dateBetweenDays = DateUtil.getDateBetweenDays(DateUtil.getDate(activityStaticReq.getStartDate()), DateUtil.getDate(activityStaticReq.getEndDate()));
//遍历日期拼接到sql里
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < dateBetweenDays.size(); i++) {
                if (i != dateBetweenDays.size() - 1) {
                    sb.append(String.format("SELECT '%s' as timeDay union all ", dateBetweenDays.get(i)));
                } else {
                    sb.append(String.format("SELECT '%s' as timeDay", dateBetweenDays.get(i)));
                }
            }
            HashMap<String, String> map = Maps.newHashMap();
            map.put("activityId", activityStaticReq.getActivityId());
            map.put("table", sb.toString());
            List<Map> shareResult = tfAccShareRecordMapper.querShare(map);            
//最后在xml里拼接sql
select DATE_FORMAT(a.timeDay,'%Y/%m/%d') as time,ifnull(b.shareNum,0) shareNum,ifnull(b.shareCount,0) shareCount,ifnull(b.newUserNum,0) newUserNum
    from (${table}) a left join (
	select DATE_FORMAT(create_time, '%Y/%m/%d') dayTime,
                    count(account_id)                    shareNum,
                    sum(share_record_count)         shareCount,
                    sum(is_new_user)                     newUserNum
                    from tf_acc_share_record o
                    where o.activity_id = #{activityId}
                    group by DATE_FORMAT(o.create_time, '%Y/%m/%d')
    ) b on DATE_FORMAT(a.timeDay, '%Y/%m/%d') = b.dayTime order by a.timeDay            
```            