---
title: 333
date: 2021-08-01 16:08:48
tags: #文章標籤 可以省略
     - 标签1
     - 标签2
categories: 1111
---
# 一级标题
==周小凤是个大傻子==
## 二级标题
```周小凤```
### 三级标题
***周小凤***
#### 四级标题
*周小凤*
##### 五级标题
周小凤
###### 六级标题

- Item 1
- Item 2
  - Item 2a
  - Item 2b

正如 Kanye West 所说：

> We're living the future so
> the present is our past.



如下，三个或者更多的
---
连字符
---
星号
---
我觉得你应该在这里使用
`<addr>` 才对。



```ruby
require 'redcarpet'
markdown = Redcarpet.new("Hello World!")
puts markdown.to_html
```

```javascript {.class1 .class}
function add(x, y) {
  return x + y
}
```

```javascript {.line-numbers}
function add(x, y) {
  return x + y
}
```

```javascript {highlight=10}
a
```

```javascript {highlight=10-20}
dsa
```

- [x] @mentions, #refs, [links](), **formatting**, and <del>tags</del> supported
- [x] list syntax required (any unordered or ordered list supported)
- [x] this is a complete item
- [ ] this is an incomplete item





[^1]: Hi! This is a footnote


- 我爱周小凤
  - 我
  - 爱
  - 周
  - 小
  - 凤

1. 我 
2. 爱 
5. 周
3. 小
5. 凤 

> 我爱周小凤

*我爱周小凤*

~~我爱周小凤~~
[百度链接](https://www.jianshu.com/p/d1d6f6da103c)在哪里啊
![图片地址](https://img1.baidu.com/it/u=197100022,1745471859&fm=26&fmt=auto&gp=0.jpg)



