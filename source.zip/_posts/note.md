---
title: note
date: 2021-08-03 21:08:54
tags:
---

# 业务

## 分享
1. 生成分享链接->根据活动id获取分享配置,如果分享,添加shareTag标识->如果链接包含?shareId=xxx,去掉这部分重新拼接长链接->获取用户登录信息,未登录直接生成短链接返回->已登录,通过活动ID和账户ID在分享表中获取分享记录->如果分享记录存在，并且长链一致，返回对应短链；否则重新生成短链，记录分享表

```
入参:
    {
      "activityId": "4ciL15mIpKZuSUWcfnNyqEtbHWmwnpZSJcy2u2XdqzU\u003d",
      "title": "55av54uC56CN5Lu3",
      "url": "/cutPrice.html?   title\u003d55av54uC56CN5Lu3\u0026activityId\u003d4ciL15mIpKZuSUWcfnNyqEtbHWmwnpZSJcy2u2Xdq zU\u003d#/cutDetail? activityId\u003d4ciL15mIpKZuSUWcfnNyqEtbHWmwnpZSJcy2u2XdqzU%3D\u0026goodsId\u003d1115712\u   0026groupId\u003d1044601"
    }
出参:
    "data": {
        "shareTag": "N",
        "sharePic": "",
        "shareTitle": "页面标题",
        "shareUrl": "/dwz/7VfM7f",
        "shareDesc": "注页面及分享信息请遵守微信朋友圈管理规定，请勿出现违规信息，否则有可能导致活动分  享到朋友圈仅自己可见"
      }
```

2. 短链接访问->根据短链接查找长链接->根据短链接paramId查找分享链接,如果paramId关联分享活动->url最后拼接上&shareId=分享人


3. 微信登录跳转轨迹
```
获取微信网页授权的完整URL为:
授权完整地址为：==> https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxbd8120fb97e3f871&redirect_uri=https%3A%2F%2Ft.hualedou.cn%2Fmarket-gateweb%2FweChat%2FgetOpenId&response_type=code&scope=snsapi_userinfo&state=111029777#wechat_redirect

授权通过，页面重定向至 :===> https://t.hualedou.cn/market-mobile/autoLogin?ticket=375e5d31cc1041b09c0322f3806b3a29

开始将页面重定向至 :===> https://t.hualedou.cn/market-h5/scratchCard.html?title=5Yiu5Yiu5LmQ&activityId=I*mR*mRHQkLVLsrDWAAv2OE1Rc6/94aHhOKfKQ58d3E=#/?_randm=6ef22aad62414bd4af1571c35faf7219
```


select DATE_FORMAT(a.timeDay, '%Y/%m/%d') as time
	, ifnull(b.shareNum, 0) as shareNum
	, ifnull(b.shareCount, 0) as shareCount
	, ifnull(b.newUserNum, 0) as newUserNum
from (
	select '2021-07-30' as timeDay
	union all
	select '2021-07-31' as timeDay
	union all
	select '2021-08-01' as timeDay
	union all
	select '2021-08-02' as timeDay
	union all
	select '2021-08-03' as timeDay
	union all
	select '2021-08-04' as timeDay
	union all
	select '2021-08-05' as timeDay
) a
	left join (
		select DATE_FORMAT(create_time, '%Y/%m/%d') as dayTime, count(account_id) as shareNum
			, count(DISTINCT account_id) as shareCount, sum(is_new_user) as newUserNum
		from tf_acc_share_record o
		where activity_id = '10029064816'
		group by o.create_time
	) b
	on DATE_FORMAT(a.timeDay, '%Y/%m/%d') = b.dayTime;
