---
title: contact
date: 2019-07-26 17:17:02
type: "contact"
layout: "contact"
---

# 欢迎留言
大家有任何问题，都可以在评论区给我留言。

我很忙啦，如果不是很麻烦的问题就直接在评论区留言啦。

# 友链交换
想要交换友链的小伙伴，欢迎在评论区留言，留言格式：
* **名称：**你的博客名称
* **地址：**你的博客地址
* **简介：**一句话简介
* **头像：**你的头像地址

例如我的博客友链，大家可以加到自己博客里哦：
* **名称：**crossoverFish
* **地址：**https://crossoverFish.com
* **简介：**公众号
* **头像：**https://crossoverFish.com/medias/avatars/avatar.jpg
